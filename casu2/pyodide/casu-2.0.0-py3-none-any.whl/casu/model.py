from .common   import dynamic, serialize, timestamp
from .geometry import MeshList, Mesh, Mat4

class Model:
    def __init__( self, attributes ):
        self.Attributes = dynamic( {
            'Settings':        { 'Type': 'fold', 'Label': 'General Settings',
            'DebugMode':       { 'Type': 'bool', 'Value': False, 'Label': 'Debug Mode', 'Hide': True },
            'CurveRadius':     { 'Type': 'real', 'Value': 0.05,  'Min': 0.01,  'Max': 0.1, 'Step': 0.01, 'Label': 'Curve Radius (m)' },
            'CurveAlong':      { 'Type': 'real', 'Value': 32,    'Min':    3,  'Max': 64,  'Step':    1, 'Label': 'Curve Segments (#)' },
            'CurveAround':     { 'Type': 'real', 'Value': 3,  'Min': 3,  'Max': 32, 'Step': 0.01, 'Label': 'Curve Profile (#)', 'Hide': True },
            'CombineMeshes':   { 'Type': 'bool', 'Value': False, 'Label': 'Combine Meshes'    },
            'NormalizeMeshes': { 'Type': 'bool', 'Value': True,  'Label': 'Normalize Meshes'  },
            'FlattenMeshes':   { 'Type': 'bool', 'Value': True,  'Label': 'Flatten Meshes', 'Hide': True    }
        } } | attributes )
        self.Meshes = MeshList( )

    @property
    def Settings( self ):
        return self.Attributes.Settings

    @property
    def CombineMeshes( self ):
        return self.Settings.CombineMeshes.Value

    @property
    def NormalizeMeshes( self ):
        return self.Settings.NormalizeMeshes.Value

    @property
    def FlattenMeshes( self ):
        return self.Settings.FlattenMeshes.Value

    @FlattenMeshes.setter
    def FlattenMeshes( self, value ):
        self.Settings.FlattenMeshes.Value = value

    @property
    def CurveResolution( self ) -> tuple[float, float, float]:
        return ( self.Settings.CurveRadius.Value,
                 self.Settings.CurveAlong.Value,
                 self.Settings.CurveAround.Value )

    @property
    def CurveRadius( self ) -> float:
        return self.Settings.CurveRadius.Value

    @property
    def CurveAlong( self ) -> int:
        return int( self.Settings.CurveAlong.Value )

    @property
    def CurveAround( self ) -> int:
        return int( self.Settings.CurveAround.Value )

    @property
    def Debug( self ):
        return self.Settings.DebugMode.Value

    def Name( self ):
        return 'Model'

    def Parameters( self ):
        return serialize( self.Attributes )

    def Callback( self, name, args ):
        return getattr( self, name )( args )

    def Upload( self, name, data ):
        pass

    def Update( self, data ):
        return self.Flush( {} )

    def Reset( self, attributes ):
        self.Attributes = attributes
        self.Meshes.Clear( )
        return self

    def Flush( self, attributes={} ):
        if( self.CombineMeshes ):
            meshes = [self.Meshes.Join( )]
            if( self.NormalizeMeshes ):
                bounds = meshes[0].BoundingBox( )
                scale = max( bounds[1,:] - bounds[0,:] )
                meshes[0].Scale( 1.0 / scale )
        else:
            meshes = self.Meshes
            if( self.NormalizeMeshes ):
                bounds = self.Meshes.BoundingBox( )
                scale = max( bounds[1,:] - bounds[0,:] )
                for mesh in meshes:
                    mesh.Scale( 1.0 / scale )
        geometry = []
        for mesh in meshes:
            if( self.FlattenMeshes ):
                points, planes, colors = mesh.Arrays( )
                geometry.append( {
                    'Points': points,
                    'Planes': planes,
                    'Colors': colors
                } )
            else:
                geometry = meshes

        return { 'Geometry':   geometry,
                 'Attributes': attributes }

    def AddAxes( self ):
        self.Meshes.Add( Mesh.Axes( Mat4.Identity( ),
            self.Settings.CurveRadius.Value ) )

    def ExportStl( self, args ):
        return { 'Data': self.Meshes.ExportStl( ),
                 'Name': timestamp( ' model.stl' ) }

    def Export3mf( self, args ):
        return { 'Data': self.Meshes.Export3mf( ),
                 'Name': timestamp( ' model.3mf' ) }

    def ExportObj( self, args ):
        return { 'Data': self.Meshes.ExportObj( ),
                 'Name': timestamp( ' model.obj' ) }

    def ExportJson( self, args ):
        return { 'Data': serialize( self.Attributes ),
                 'Name': timestamp( ' model.json' ) }