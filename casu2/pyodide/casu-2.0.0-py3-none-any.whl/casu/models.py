from .classic import Classic
# from .modern  import Modern
from .common  import dynamic

class Models:
    def __init__( self ):
        #self.Models = [Classic( ), Modern( )]
        self.Models = [Classic( )]
        self.Active = self.Models[0]

    def Activate( self, index ):
        self.Active = self.Models[index]
        return True

    def Parameters( self ):
        return self.Active.Parameters( )

    def Available( self ):
        return { model.Name( ):index
            for index, model in enumerate( self.Models ) }

    def Update( self, attributes ):
        return self.Active.Update(
            dynamic( attributes.to_py( ) ) )

    def Upload( self, name, data ):
        return self.Active.Upload( name, data )

    def Callback( self, name, args ):
        return self.Active.Callback( name, args )

