from __future__ import annotations
import math, numpy as np, trimesh
from typing import Union

class Rgba:
    R: list[int] = [0xff, 0x00, 0x00, 0xff]
    G: list[int] = [0x00, 0xff, 0x00, 0xff]
    B: list[int] = [0x00, 0x00, 0xff, 0xff]

    Types10: list[list[int]] = [
        [0x1f, 0x77, 0xb4, 0xff],
        [0xff, 0x7f, 0x0e, 0xff],
        [0x2c, 0xa0, 0x2c, 0xff],
        [0xd6, 0x27, 0x28, 0xff],
        [0x94, 0x67, 0xbd, 0xff],
        [0x8c, 0x56, 0x4b, 0xff],
        [0xe3, 0x77, 0xc2, 0xff],
        [0x7f, 0x7f, 0x7f, 0xff],
        [0xbc, 0xbd, 0x22, 0xff],
        [0x17, 0xbe, 0xcf, 0xff],
        [0xff, 0xff, 0xff, 0x80]]
    
    TypesFF: list[list[int]] = None

Rgba.TypesFF = np.array( [Rgba.Types10[index % 10][:3] 
    for index in range( 255 )] + [[0xff, 0xff, 0xff]] ).flatten( ).tolist( )

class Vec1:
    D2R = math.pi / 180.0
    R2D = 180.0 / math.pi

class Vec3:
    Zero  : Vec3 = None
    Unit  : Vec3 = None
    XAxis : Vec3 = None
    YAxis : Vec3 = None
    ZAxis : Vec3 = None

    def __init__( self, x, y, z ):
        self.X = x
        self.Y = y
        self.Z = z

    def __add__( self, that : Vec3 ) -> Vec3:
        return Vec3(
            self.X + that.X,
            self.Y + that.Y,
            self.Z + that.Z )

    def __sub__( self, that : Vec3 ) -> Vec3:
        return Vec3(
            self.X - that.X,
            self.Y - that.Y,
            self.Z - that.Z )

    def __mul__( self, that ):
        if( isinstance( that, Vec3 ) ):
            return float(
                self.X * that.X +
                self.Y * that.Y +
                self.Z * that.Z )
        if( isinstance( that, ( int, float ) ) ):
            return Vec3(
                self.X * that,
                self.Y * that,
                self.Z * that )
        if( isinstance( that, Mat4 ) ):
            return that.MatrixPointProduct( self )

    def ToNumPy( self ) -> np.ndarray:
        return np.array( [ self.X, self.Y, self.Z ] )

    def ToTuple( self ) -> tuple[float, float, float]:
        return ( self.X, self.Y, self.Z )
    
    def ToList( self ) -> list[float]:
        return [self.X, self.Y, self.Z]

    @staticmethod
    def FromNumPy( array: np.ndarray ) -> Vec3:
        return Vec3( array[0], array[1], array[2] )

    @property
    def Length( self ):
        return math.sqrt(
            self.X ** 2 +
            self.Y ** 2 +
            self.Z ** 2 )

    @staticmethod
    def CrossProduct( u: Vec3, v: Vec3 ) -> Vec3:
        return Vec3(
            u.Y * v.Z - u.Z * v.Y,
            u.Z * v.X - u.X * v.Z,
            u.X * v.Y - u.Y * v.X )
    
    def Cross( self, that: Vec3 ) -> Vec3:
        return Vec3.CrossProduct( self, that )

    @staticmethod
    def UnaryCrossProduct( u: Vec3 ) -> Vec3:
        if( abs( u.X ) < abs( u.Y ) ):
            if( abs( u.X ) < abs( u.Z ) ):
                w = Vec3.XAxis
            else:
                w = Vec3.ZAxis
        else:
            if( abs( u.Y ) < abs( u.Z ) ):
                w = Vec3.YAxis
            else:
                w = Vec3.ZAxis
        return Vec3.CrossProduct( u, w )

    def UnaryCross( self ) -> Vec3:
        return Vec3.UnaryCrossProduct( self )

    def Normalize( self, length = 1.0 ) -> Vec3:
        scale = self.Length
        scale = length / scale if( scale > 0 ) else 0.0
        self.X *= scale
        self.Y *= scale
        self.Z *= scale
        return self

    def Decompose( self, epsilon = 1e-15 ) -> tuple[Vec3, float]:
        length = self.Length
        scale = 1.0 / length if( length > epsilon ) else 0.0
        return self * scale, length

    @staticmethod
    def Normal( u: Vec3, v: Vec3 ) -> Vec3:
        return Vec3.CrossProduct( u, v ).Normalize( )

Vec3.Zero  = Vec3( 0.0, 0.0, 0.0 )
Vec3.Unit  = Vec3( 1.0, 1.0, 1.0 )
Vec3.XAxis = Vec3( 1.0, 0.0, 0.0 )
Vec3.YAxis = Vec3( 0.0, 1.0, 0.0 )
Vec3.ZAxis = Vec3( 0.0, 0.0, 1.0 )

class Vec4:
    def __init__( self, x : float, y: float, z: float, w: float ):
        self.X = x
        self.Y = y
        self.Z = z
        self.W = w

class Mat4:
    WorldXY : Mat4 = None
    WorldYZ : Mat4 = None
    WorldZX : Mat4 = None

    def __init__( self,
            xx = 1.0, yx = 0.0, zx = 0.0, wx = 0.0,
            xy = 0.0, yy = 1.0, zy = 0.0, wy = 0.0,
            xz = 0.0, yz = 0.0, zz = 1.0, wz = 0.0,
            xw = 0.0, yw = 0.0, zw = 0.0, ww = 1.0 ):
        self.X = Vec4( xx, xy, xz, xw )
        self.Y = Vec4( yx, yy, yz, yw )
        self.Z = Vec4( zx, zy, zz, zw )
        self.W = Vec4( wx, wy, wz, ww )

    @property
    def Origin( self ) -> Vec3:
        return Vec3( self.W.X, self.W.Y, self.W.Z )

    @property
    def XAxis( self ) -> Vec3:
        return Vec3( self.X.X, self.X.Y, self.X.Z )
    @property
    def YAxis( self ) -> Vec3:
        return Vec3( self.Y.X, self.Y.Y, self.Y.Z )

    @property
    def ZAxis( self ) -> Vec3:
        return Vec3( self.Z.X, self.Z.Y, self.Z.Z )

    @property
    def Decompose( self ) -> tuple[Vec3, Vec3, Vec3, Vec3]:
        return ( self.Origin,
                 self.XAxis,
                 self.YAxis,
                 self.ZAxis )

    """ Identity Matrix
    """
    @staticmethod
    def Identity( ):
        return Mat4( )

    """ Matrix from Basis
    """
    @staticmethod
    def Basis( o : Vec3, x : Vec3, y : Vec3, z : Vec3 ):
        return Mat4( x.X, y.X, z.X, o.X,
                     x.Y, y.Y, z.Y, o.Y,
                     x.Z, y.Z, z.Z, o.Z,
                     0.0, 0.0, 0.0, 1.0 )

    """ Matrix from Plane
    """
    @staticmethod
    def Plane( o : Vec3, x : Vec3, y : Vec3 ) -> Mat4:
        return Mat4.Basis( o, x, y,
            Vec3.CrossProduct( x, y ) )

    def MatrixPointProduct( self, point : Vec3 ) -> Vec3:
        xx, yx, zx = self.X.X, self.Y.X, self.Z.X
        xy, yy, zy = self.X.Y, self.Y.Y, self.Z.Y
        xz, yz, zz = self.X.Z, self.Y.Z, self.Z.Z
        ox, oy, oz = self.W.X, self.W.Y, self.W.Z
        return Vec3(
            ox + xx * point.X + yx * point.Y + zx * point.Z,
            oy + xy * point.X + yy * point.Y + zy * point.Z,
            oz + xz * point.X + yz * point.Y + zz * point.Z )

    def MatrixVectorProduct( self, vector : Vec3 ) -> Vec3:
        xx, yx, zx = self.X.X, self.Y.X, self.Z.X
        xy, yy, zy = self.X.Y, self.Y.Y, self.Z.Y
        xz, yz, zz = self.X.Z, self.Y.Z, self.Z.Z
        return Vec3(
            xx * vector.X + yx * vector.Y + zx * vector.Z,
            xy * vector.X + yy * vector.Y + zy * vector.Z,
            xz * vector.X + yz * vector.Y + zz * vector.Z )

    def MatrixMatrixProduct( self, that : Mat4 ) -> Mat4:
        """ Unpack Matrix Elements
        """
        sxx, syx, szx, swx = self.X.X, self.Y.X, self.Z.X, self.W.X
        sxy, syy, szy, swy = self.X.Y, self.Y.Y, self.Z.Y, self.W.Y
        sxz, syz, szz, swz = self.X.Z, self.Y.Z, self.Z.Z, self.W.Z
        sxw, syw, szw, sww = self.X.W, self.Y.W, self.Z.W, self.W.W

        txx, tyx, tzx, twx = that.X.X, that.Y.X, that.Z.X, that.W.X
        txy, tyy, tzy, twy = that.X.Y, that.Y.Y, that.Z.Y, that.W.Y
        txz, tyz, tzz, twz = that.X.Z, that.Y.Z, that.Z.Z, that.W.Z
        txw, tyw, tzw, tww = that.X.W, that.Y.W, that.Z.W, that.W.W

        """ Product Matrix Elements
        """
        rxx = sxx * txx + syx * txy + szx * txz + swx * txw
        ryx = sxx * tyx + syx * tyy + szx * tyz + swx * tyw
        rzx = sxx * tzx + syx * tzy + szx * tzz + swx * tzw
        rwx = sxx * twx + syx * twy + szx * twz + swx * tww

        rxy = sxy * txx + syy * txy + szy * txz + swy * txw
        ryy = sxy * tyx + syy * tyy + szy * tyz + swy * tyw
        rzy = sxy * tzx + syy * tzy + szy * tzz + swy * tzw
        rwy = sxy * twx + syy * twy + szy * twz + swy * tww

        rxz = sxz * txx + syz * txy + szz * txz + swz * txw
        ryz = sxz * tyx + syz * tyy + szz * tyz + swz * tyw
        rzz = sxz * tzx + syz * tzy + szz * tzz + swz * tzw
        rwz = sxz * twx + syz * twy + szz * twz + swz * tww

        rxw = sxw * txx + syw * txy + szw * txz + sww * txw
        ryw = sxw * tyx + syw * tyy + szw * tyz + sww * tyw
        rzw = sxw * tzx + syw * tzy + szw * tzz + sww * tzw
        rww = sxw * twx + syw * twy + szw * twz + sww * tww

        return Mat4(
            rxx, ryx, rzx, rwx,
            rxy, ryy, rzy, rwy,
            rxz, ryz, rzz, rwz,
            rxw, ryw, rzw, rww )

    def __mul__( self, that ):
        if( isinstance( that, Mat4 ) ):
            return self.MatrixMatrixProduct( that )

        if( isinstance( that, Vec3 ) ):
            return self.MatrixPointProduct( that )

        raise Exception( 'Unsupported Multiplication', type( that ) )

    @property
    def Inverse( self ):
        """ Unpack Matrix Elements
        """
        xx, yx, zx, wx = self.X.X, self.Y.X, self.Z.X, self.W.X
        xy, yy, zy, wy = self.X.Y, self.Y.Y, self.Z.Y, self.W.Y
        xz, yz, zz, wz = self.X.Z, self.Y.Z, self.Z.Z, self.W.Z
        xw, yw, zw, ww = self.X.W, self.Y.W, self.Z.W, self.W.W

        """ Minor Determinants
        """
        t00 = xx * yy - yx * xy
        t01 = xx * zy - zx * xy
        t02 = xx * wy - wx * xy
        t03 = yx * zy - zx * yy
        t04 = yx * wy - wx * yy
        t05 = zx * wy - wx * zy
        t06 = xz * yw - yz * xw
        t07 = xz * zw - zz * xw
        t08 = xz * ww - wz * xw
        t09 = yz * zw - zz * yw
        t10 = yz * ww - wz * yw
        t11 = zz * ww - wz * zw

        """ Determinant (unsafe)
        """
        det = 1.0 / ( t00 * t11 - t01 * t10 +
                      t02 * t09 + t03 * t08 -
                      t04 * t07 + t05 * t06 )

        """ Matrix Inverse
        """
        return Mat4(
            det * ( yy * t11 - zy * t10 + wy * t09 ),
            det * ( zx * t10 - wx * t09 - yx * t11 ),
            det * ( yw * t05 - zw * t04 + ww * t03 ),
            det * ( zz * t04 - wz * t03 - yz * t05 ),

            det * ( zy * t08 - wy * t07 - xy * t11 ),
            det * ( xx * t11 - zx * t08 + wx * t07 ),
            det * ( zw * t02 - ww * t01 - xw * t05 ),
            det * ( xz * t05 - zz * t02 + wz * t01 ),

            det * ( xy * t10 - yy * t08 + wy * t06 ),
            det * ( yx * t08 - wx * t06 - xx * t10 ),
            det * ( xw * t04 - yw * t02 + ww * t00 ),
            det * ( yz * t02 - wz * t00 - xz * t04 ),

            det * ( yy * t07 - zy * t06 - xy * t09 ),
            det * ( xx * t09 - yx * t07 + zx * t06 ),
            det * ( yw * t01 - zw * t00 - xw * t03 ),
            det * ( xz * t03 - yz * t01 + zz * t00 ) )

    @property
    def Reverse( self ):
        xx, yx, zx, wx = self.X.X, self.Y.X, self.Z.X, self.W.X
        xy, yy, zy, wy = self.X.Y, self.Y.Y, self.Z.Y, self.W.Y
        xz, yz, zz, wz = self.X.Z, self.Y.Z, self.Z.Z, self.W.Z
        wx, wy, wz, ww = self.W.X, self.W.Y, self.W.Z, self.W.W

        return Mat4(
            xx, xy, xz, -( wx * xx + wy * xy + wz * xz ),
            yx, yy, yz, -( wx * yx + wy * yy + wz * yz ),
            zx, zy, zz, -( wx * zx + wy * zy + wz * zz ) )

    @staticmethod
    def BasisToBasis( source, target ):
          return target * source.Reverse

    def ToNumPy( self ) -> np.ndarray:
        return np.array( [
            [ self.X.X, self.Y.X, self.Z.X, self.W.X ],
            [ self.X.Y, self.Y.Y, self.Z.Y, self.W.Y ],
            [ self.X.Z, self.Y.Z, self.Z.Z, self.W.Z ],
            [ self.X.W, self.Y.W, self.Z.W, self.W.W ] ] )

Mat4.WorldXY = Mat4(
    1.0, 0.0, 0.0, 0.0,
    0.0, 1.0, 0.0, 0.0,
    0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 1.0 )

Mat4.WorldYZ = Mat4(
    0.0, 0.0, 0.0, 0.0,
    0.0, 1.0, 0.0, 0.0,
    0.0, 0.0, 1.0, 0.0,
    1.0, 0.0, 0.0, 1.0 )

Mat4.WorldZX = Mat4(
    0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 1.0, 0.0,
    1.0, 0.0, 0.0, 0.0,
    0.0, 1.0, 0.0, 1.0 )

class Curve:
    def Evaluate( self, t: float ) -> Vec3:
        pass

    def Tangent( self, t: float ) -> Vec3:
        pass

    def Normal( self, t: float ) -> Vec3:
        pass

    def Frame( self, t: float ) -> Mat4:
        o = self.Evaluate( t )
        u = self.Tangent( t )
        v = self.Normal( t )
        return Mat4.Plane( o, u, v )
    
    def DivideByCount( self, count : int ) -> list[Vec3]:
        return [self.Evaluate( index / count )
                    for index in range( count + 1 )]
    
class Surface:
    def Evaluate( self, u: float, v: float ) -> Vec3:
        pass

    def DivideByCount( self, count: list[int] ) -> list[list[Vec3]]:
        nu, nv = count
        return [
            [self.Evaluate( iu / nu, iv / nv )
                for iu in range( nu + 1 ) ]
                    for iv in range( nv + 1 )] 
    
class LineCurve( Curve ):
    def __init__( self, source: Vec3, target: Vec3 ):
        super( ).__init__( )
        self.Source = source
        self.Target = target

    def Evaluate( self, t: float ) -> Vec3:
        return self.Source * ( 1 - t ) + self.Target * t

    def Tangent( self, t: float ) -> Vec3:
        return ( self.Target - self.Source ).Normalize( )

    def Normal( self, t: float ) -> Vec3:
        u = self.Tangent( t )
        return u.UnaryCross( )

    def Frame( self, t: float ) -> Mat4:
        o = self.Evaluate( t )
        u = self.Tangent( t )
        v = u.UnaryCross( )
        return Mat4.Plane( o, u, v )

    def Transform( self, matrix: Mat4 ) -> LineCurve:
        return LineCurve(
            matrix * self.Source,
            matrix * self.Target )

class ArcCurve( Curve ):
    def __init__( self, plane, radius, angle ):
        super( ).__init__( )
        self.Plane  = plane
        self.Radius = radius
        self.Angle  = angle

    def Evaluate( self, t ):
        theta = self.Angle * t
        x = self.Radius * math.cos( theta )
        y = self.Radius * math.sin( theta )
        return ( self.Plane.Origin +
                 self.Plane.XAxis * x +
                 self.Plane.YAxis * y )

    @staticmethod
    def FromThreePoints( source, middle, target ):
        u = middle - source
        v = target - middle
        n = Vec3.Normal( u, v )

        sm = ( source + middle ) * 0.5
        mt = ( middle + target ) * 0.5

        nu = Vec3.CrossProduct( n, u )
        vn = Vec3.CrossProduct( v, n )

        A = np.column_stack( ( nu.ToNumPy( ), vn.ToNumPy( ) ) )
        b = ( mt - sm ).ToNumPy( )
        t, _ = np.linalg.lstsq( A, b, rcond=None )[0:2]
        center = sm + Vec3.FromNumPy( t[0] * nu.ToNumPy( ) )

        xaxis, radius = ( source - center ).Decompose( )
        yaxis = Vec3.Normal( n, xaxis )
        plane = Mat4.Plane( center, xaxis, yaxis )
        angle = math.acos( np.clip( np.dot( xaxis, ( target - center ).Normalize( ) ), -1.0, 1.0 ) )
        return ArcCurve( plane, radius, angle )

    def Tangent( self, t ) -> Vec3:
        theta = self.Angle * t
        dx = -self.Radius * math.sin( theta ) * self.Angle
        dy =  self.Radius * math.cos( theta ) * self.Angle
        return ( self.Plane.XAxis * dx +
                 self.Plane.YAxis * dy ).Normalize( )

    def Normal( self, t ):
        theta = self.Angle * t
        dx = -self.Radius * math.cos( theta )
        dy = -self.Radius * math.sin( theta )
        return ( self.Plane.XAxis * dx +
                 self.Plane.YAxis * dy ).Normalize( )



""" Evaluate Bezier at Parameter
"""
class BezierCurve( Curve ):
    def __init__( self, points ):
        super( ).__init__( )
        self.Points = points

    @property
    def Degree( self ):
        return len( self.Points ) - 1

    @staticmethod
    def DeCasteljau( points, t ) -> Vec3:
        if( len( points ) == 1 ):
            return points[0]
        new_points = []
        for source, target in zip( points[:-1], points[1:] ):
            new_points.append( source * ( 1 - t ) + target * t )
        return BezierCurve.DeCasteljau( new_points, t )

    def Evaluate( self, t ) -> Vec3:
        return BezierCurve.DeCasteljau( self.Points, t )

    """ Derivative / Hodograph Curve
    """
    def Derive( self ) -> BezierCurve:
        d = self.Degree
        points = [( target - source ) * d
            for source, target in zip(
                self.Points[:-1], self.Points[1:] )]
        return BezierCurve( points )

    """ Derivatives at Parameter
    """
    def Derivatives( self, t, n = -1 ) -> list[Vec3]:
        d = self.Degree
        if( n < 0 or
            n > d ):
            n = d
        curve = self
        delta = [curve.Evaluate( t )] * ( n + 1 )
        for k in range( 1, n + 1 ):
            curve = curve.Derive( )
            delta[k] = curve.Evaluate( t )
        return delta

    """ Tangent Vector
    """
    def Tangent( self, t ) -> Vec3:
        _, u = self.Derivatives( t, 1 )
        return u.Normalize( )

    """ Normal Vector
    """
    def Normal( self, t ) -> Vec3:
        _, u, v = self.Derivatives( t, 2 )
        return Vec3.Normal( u, v )

    """ Fresnet Frame
    """
    def Frame( self, t ):
        o, u, v = self.Derivatives( t, 2 )
        n = Vec3.CrossProduct( u, v )
        v = Vec3.CrossProduct( n, u )
        return Mat4.Basis( o, 
            u.Normalize( ), 
            v.Normalize( ), 
            n.Normalize( ) )

    """ Curvature
    """
    def Curvature( self, t ):
        _, u, v = self.Derivatives( t, 2 )
        return Vec3.CrossProduct( u, v ).Length / u.Length ** 3

    """ Torsion
    """
    def Torsion( self, t ):
        o, u, v, w = self.Derivatives( t, 3 )
        x = Vec3.CrossProduct( u, v )
        return ( x * w ) / ( x * x )

class BezierSurface:
    def __init__( self, points ):
        self.Points = points

    def Evaluate( self, u, v ):
        curves = [BezierCurve( row )
            for row in self.Points]

        points = [curve.Evaluate( u )
            for curve in curves]

        curve = BezierCurve( points )
        return curve.Evaluate( v )
    
class BasisSplineCurve( Curve ):
    """ Construction
    """
    def __init__( self, points, degree ):
        super( ).__init__( )
        self.Points = points
        self.Degree = degree
        self.Knots  = self.ClampedKnots( )

    """ Open Knot Vector
    """
    def OpenKnots( self ):
        n, d = len( self.Points ), self.Degree
        return [i / ( n + d )
            for i in range( n + d + 1 )]

    """ Clamped Knot Vector
    """
    def ClampedKnots( self ):
        n, d = len( self.Points ), self.Degree
        k_min = [0.0] * d
        k_mid = [i / ( n - d ) for i in range( n - d + 1 )]
        k_max = [1.0] * d
        return k_min + k_mid + k_max

    """ Periodic Knot Vector
    """
    def PeriodicKnots( self ):
        n, d = len( self.Points ), self.Degree
        return [( i - d  ) / ( n - d )
            for i in range( n + d + 1 )]

    """ Find Knot Span Containing Parameter
    """
    def KnotSpan( self, t ):
        n, d = len( self.Points ), self.Degree
        if( t <= self.Knots[d] ): return d, d
        if( t >= self.Knots[n] ): return d, n - 1
        for knot, ( k_min, k_max ) in enumerate(
                zip( self.Knots[:-1], self.Knots[1:] ) ):
            if( k_min <= t <  k_max or
                k_min <  t <= k_max ):
                return d, knot

    """ De Boor's Algorithm
    """
    def Evaluate( self, t ):
        #-- Relevant Knots and Points
        #--
        d, k = self.KnotSpan( t )
        P = self.Points[k-d:k+1]

        #-- Recursive Interpolations
        #--
        for i in range( d ):
            for j in range( d, i, -1 ):
                to = self.Knots[j + k - d]
                ti = self.Knots[j + k - i]

                alpha = ( t - to ) / ( ti - to )
                omega = 1.0 - alpha

                P[j] = omega * P[j - 1] + alpha * P[j]
        return P[-1]

    """ Derivative / Hodograph Curve
    """
    def Derive( self ):
        d = self.Degree
        points = []
        for i in range( 1, len( self.Points ) ):
            po, ko = self.Points[i-1], self.Knots[i  ]
            pi, ki = self.Points[i  ], self.Knots[i+d]
            point = ( pi - po ) * d / ( ki - ko )
            points.append( point )
        curve = BasisSplineCurve( points, d - 1 )
        curve.Knots = self.Knots[1:-1]
        return curve

    def Derivatives( self, t, n = -1 ):
        d = self.Degree
        if( n < 0 or
            n > d ):
            n = d
        curve = self
        delta = [curve.Evaluate( t )] * ( n + 1 )
        for k in range( 1, n + 1 ):
            curve = curve.Derive( )
            delta[k] = curve.Evaluate( t )
        return delta

class BasisSplineSurface:
    def __init__( self, points, degree = [1, 1] ):
        self.Points = points
        self.Degree = degree

    def Evaluate( self, u, v ):
        curves = [BasisSplineCurve( row, self.Degree[0] )
            for row in self.Points]

        points = [curve.Evaluate( u )
            for curve in curves]

        curve = BasisSplineCurve( points, self.Degree[1] )
        return curve.Evaluate( v )
    
""" Rational BSpline Curve
"""
class RationalBSplineCurve( BasisSplineCurve ):
    """ Construction
    """
    def __init__( self, points, degree ):
        super( ).__init__( points, degree )

    """ Decouple Points and Weights
    """
    def Decouple( self, points : np.ndarray ):
        P = [Vec3( p.X * p.W,
                   p.Y * p.W,
                   p.Z * p.W )
                 for p in points]
        W = [p.W for p in points]
        return P, W

    """ Evaluate Point
    """
    def Evaluate( self, t ):
        d, k = self.KnotSpan( t )
        P, W = self.Decouple( self.Points[k-d:k+1] )
        K = self.Knots[k-d:k+d+1]

        A = BasisSplineCurve( P, d ); A.Knots = K
        w = BasisSplineCurve( W, d ); w.Knots = K

        return A.Evaluate( t ) / w.Evaluate( t )

    """ Nurbs Derivatives
    """
    def Derivatives( self, t, n = -1 ):
        d = self.Degree
        if( n < 0 or
            n > d ):
            n = d

        """ Non-Rational Derivatives
        """
        P, W = self.Decouple( self.Points )
        A = BasisSplineCurve( P, d ); A.Knots = self.Knots
        w = BasisSplineCurve( W, d ); w.Knots = self.Knots

        dA = A.Derivatives( t, n )
        dw = w.Derivatives( t, n )

        """ Rational Derivatives
        """
        D = [1.0] * ( n + 1 )
        for k in range( n + 1 ):
            u = dA[k]
            for i in range( 1, k + 1 ):
                u -= math.comb( k, i ) * dw[i] * D[k - i]
            D[k] = u / dw[0]
        return D

class RationalBSplineSurface:
    def __init__( self, points, degree = [1, 1] ):
        self.Points = points
        self.Degree = degree

    def Evaluate( self, u, v ):
        curves = [RationalBSplineCurve( row, self.Degree[0] )
            for row in self.Points]

        points = [curve.Evaluate( u )
            for curve in curves]

        curve = RationalBSplineCurve( points, self.Degree[1] )
        return curve.Evaluate( v )

class SweepSurface( Surface ):

    def __init__( self, profile: Curve, rail: Curve, guide: Union[Vec3,None]=None ):        
        self.Profile = profile
        self.Rail = rail
        self.Guide = guide

    def Evaluate( self, u: float, v: float ) -> Vec3:
        plane = self.Rail.Frame( v )
        if( self.Guide is not None ):
            x = plane.XAxis
            y = Vec3.Normal( self.Guide, x )
            z = Vec3.CrossProduct( x, y )
            plane = Mat4.Basis( plane.Origin, x, y, z )
        matrix = Mat4.BasisToBasis( Mat4.WorldYZ, plane )
        point = self.Profile.Evaluate( u )
        return point * matrix



class Mesh:
    def __init__( self, geometry: Union[trimesh.Trimesh,None]=None ):
        self.Geometry = geometry
        self.Category = 'undefined'

    @staticmethod
    def Axes( plane: Mat4, radius=0.1, length=1.0, sections=6 ) -> Mesh:
        o, x, y, z = plane.Decompose
        xaxis = Mesh.Line( o, o + x * length, radius, sections ).Paint( Rgba.R )
        yaxis = Mesh.Line( o, o + y * length, radius, sections ).Paint( Rgba.G )
        zaxis = Mesh.Line( o, o + z * length, radius, sections ).Paint( Rgba.B )
        return Mesh.Join( [xaxis, yaxis, zaxis] )

    @staticmethod
    def Box( basis: Union[Vec3,Mat4,None]=None, size: Union[Vec3,None]=None ):
        if( size is None ): size = Vec3.Unit
        box = trimesh.creation.box( size.ToNumPy( ) )
        if( isinstance( basis, Mat4 ) ):
            matrix = Mat4.BasisToBasis( Mat4.WorldXY, basis )
            box.apply_transform( matrix.ToNumPy( ) )
        elif( isinstance( basis, Vec3 ) ):
            box.apply_translation( basis.ToNumPy( ) )
        return Mesh( box )

    @staticmethod
    def Cylinder( basis: Union[Vec3,Mat4,None]=None, radius: float=1.0, height: float=1.0, sections=16 ):
        cylinder = trimesh.creation.cylinder(
            radius, height, sections=sections )
        if( isinstance( basis, Mat4 ) ):
            matrix = Mat4.BasisToBasis( Mat4.WorldXY, basis )
            cylinder.apply_transform( matrix.ToNumPy( ) )
        elif( isinstance( basis, Vec3 ) ):
            cylinder.apply_translation( basis.ToNumPy( ) )
        return Mesh( cylinder )

    @staticmethod
    def Join( meshes: list[Mesh] ) -> Mesh:
        return Mesh( trimesh.util.concatenate(
            [mesh.Geometry for mesh in meshes] ) )

    @staticmethod
    def Line( source: Vec3, target: Vec3, radius: float=1.0, sections: int=3 ) -> Mesh:
        direction, height = ( target - source ).Decompose( )
        cylinder = trimesh.creation.cylinder(
            radius, height, sections=sections )
        matrix = trimesh.geometry.align_vectors(
            [0, 0, 1], direction.ToNumPy( ) )
        cylinder.apply_transform( matrix )
        midpoint = ( source + target ) * 0.5
        cylinder.apply_translation( midpoint.ToNumPy( ) )
        return Mesh( cylinder )

    @staticmethod
    def Curve( curve : Curve, resolution=( 0.1, 8, 3 ) ):
        radius, count, sections = resolution
        poly = curve.DivideByCount( count )
        return Mesh.Join( [Mesh.Line( source, target, radius, sections )
            for source, target in zip( poly[:-1], poly[1:] )] )

    def Translate( self, vector : Vec3 ) -> Mesh:
        self.Geometry.apply_translation( vector.ToNumPy( ) )
        return self

    def Rotate( self, axis: Vec3, angle: float, origin: Union[Vec3,None]=None ) -> Mesh:
        if( origin is None ): origin = Vec3.Zero
        matrix = trimesh.transformations.rotation_matrix(
            angle, axis.ToNumPy( ), origin.ToNumPy( ) )
        self.Geometry.apply_transform( matrix )
        return self

    @staticmethod
    def Grid( points : list[list[Vec3]] ):
        nu = len( points ) - 1
        nv = len( points[0] ) - 1

        vertices = []
        for row in points:
            for point in row:
                vertices.append( point.ToNumPy( ) )

        faces = []
        for i in range( nu ):
            for j in range( nv ):
                a = ( i + 0 ) * ( nv + 1 ) + j + 0
                b = ( i + 0 ) * ( nv + 1 ) + j + 1
                c = ( i + 1 ) * ( nv + 1 ) + j + 1
                d = ( i + 1 ) * ( nv + 1 ) + j + 0

                faces.append( [a, b, c] )
                faces.append( [a, c, d] )

        return Mesh( trimesh.Trimesh(
            vertices=np.array( vertices ),
            faces=np.array( faces ) ) )

    @staticmethod
    def Sweep( profile : Curve, path : Curve, resolution=( 8, 16 ) ):
        profile_count, path_count = resolution
        points = profile.DivideByCount( profile_count )

        vertices = []
        for index in range( path_count + 1 ):
            plane = path.Frame( index / path_count )
            transform = Mat4.BasisToBasis( Mat4.WorldYZ, plane )
            for point in points:
                vertices.append( ( point * transform ).ToNumPy( ) )

        faces = []
        for i in range( path_count ):
            for j in range( profile_count ):
                a = ( i + 0 ) * ( profile_count + 1 ) + j + 0
                b = ( i + 0 ) * ( profile_count + 1 ) + j + 1
                c = ( i + 1 ) * ( profile_count + 1 ) + j + 1
                d = ( i + 1 ) * ( profile_count + 1 ) + j + 0

                faces.append( [a, b, c] )
                faces.append( [a, c, d] )

        return Mesh( trimesh.Trimesh(
            vertices=np.array( vertices ),
            faces=np.array( faces ) ) )

    def BoundingBox( self ):
        return self.Geometry.bounds

    def Scale( self, scale ):
        self.Geometry.apply_scale( scale )
        return self

    def Categorize( self, category ):
        self.Category = category
        return self

    def Paint( self, color : list[int] ):
        self.Geometry.visual.vertex_colors = [color] * len( self.Geometry.vertices )
        return self

    def Arrays( self ):
        points = self.Geometry.vertices.flatten( ).tolist( )
        planes = self.Geometry.faces.flatten( ).tolist( )
        colors = ( self.Geometry.visual.vertex_colors.astype(
            float ) / 255.0 ).flatten( ).tolist( )
        return ( points, planes, colors )

class MeshList:
    def __init__( self ):
        self.Meshes = []

    @property
    def Count( self ):
        return len( self.Meshes )

    def __iter__( self ):
        for mesh in self.Meshes:
            yield mesh

    def __getitem__( self, index ):
        return self.Meshes[index]

    def Add( self, mesh ):
        self.Meshes.append( mesh )
        return self

    def ToTrimesh( self ):
        return [mesh.Geometry
            for mesh in self.Meshes]

    def Clear( self ):
        self.Meshes = []
        return self

    def Join( self ):
        return Mesh.Join( self.Meshes )

    def BoundingBox( self ):
        bounds = np.array( [[ np.inf,  np.inf,  np.inf ],
                            [-np.inf, -np.inf, -np.inf ]] )
        for mesh in self.Meshes:
            box = mesh.Geometry.bounds
            bounds[0,:] = np.minimum( bounds[0,:], box[0,:] )
            bounds[1,:] = np.maximum( bounds[1,:], box[1,:] )
        return bounds

    def Boolean( self, sources, targets, operation ):
        def LoadMesh( mesh, points, planes ):
            points.append( mesh.vertices.astype( np.float32 ) )
            planes.append( mesh.faces   .astype( np.uint32  ) )
            return self

        def LoadMeshes( meshes, points, planes ):
            for mesh in meshes:
                LoadMesh( mesh.Geometry, points, planes )
            return self

        source_points = []; source_planes = []
        target_points = []; target_planes = []
        LoadMeshes( sources, source_points, source_planes )
        LoadMeshes( targets, target_points, target_planes )

        from pyomanifold import Add, Sub # type: ignore
        ops = { 'Add': Add, 'Sub': Sub }
        points, planes = ops[operation](
            source_points, source_planes,
            target_points, target_planes )

        return Mesh( trimesh.Trimesh(
            vertices=points, faces=planes ) )

    def BooleanSolid( self ):
        groups = { 'positive': [], 'negative': [], 'base': [self.Meshes[0]] }
        for mesh in self.Meshes[1:]:
            if( mesh.Category == 'undefined' ): continue
            groups[mesh.Category].append( mesh )
        solid = self.Boolean( groups['base'], groups['positive'], 'Add' )
        solid = self.Boolean( [solid], groups['negative'], 'Sub' )
        return solid

    def Export3mf( self ):
        scene = trimesh.Scene( self.ToTrimesh( ) )
        return scene.export( file_type='3mf' )

    def ExportObj( self ):
        scene = trimesh.Scene( self.ToTrimesh( ) )
        return scene.export( file_type='obj' )

    def ExportStl( self ):
        solid = self.BooleanSolid( )
        scene = trimesh.Scene( [solid.Geometry] )
        return scene.export( file_type='stl' )