from .common import deserialize, serialize, encode, shannon, leibovici, eigenvalues, sinkhorn, joint, batty, timestamp
from .model import Model
from .geometry import Rgba, Vec1, Vec3, Mesh, MeshList
from PIL import Image, ImageDraw
import numpy as np, trimesh, pickle # pyright: ignore[reportMissingImports]

X, Y, R, H, T, S, A, N = 0, 1, 2, 3, 4, 5, 6, 7
D2R = np.pi / 180.0

def relative( value, minimum, maximum ):
    return 1.0 if maximum == minimum else ( value - minimum ) / ( maximum - minimum )

class Classic ( Model ):
    def __init__( self ):
        print( 'Casu 2.0 - Stylianos Dritsas 2026' )
        super( ).__init__( {
            'Diversity':      { 'Type': 'fold', 'Label': 'Population', 'Hint': 'Controls the variety and distribution of objects',
            'Population':     { 'Type': 'real', 'Value':       25,  'Min':   1, 'Max':  100, 'Step': 1, 'Label':'Number of Elements (#)'},
            'Types':          { 'Type': 'size', 'Value':        2,  'Min':   1, 'Max':   10, 'Step': 1, 'Adjusts': 'Abundances', 'Label': 'Number of Types (#)'},
            'Abundances':     { 'Type': 'list', 'Count':        2,  'Min':   2, 'Max':   98, 'Step': 1, 'Item0': 50, 'Item1': 50, 'Label': 'Relative Abundance (%)'}},
            'Dimensions':     {               'Type': 'fold',
            'Width':          {'Type': 'real', 'Value':      400,  'Min': 100, 'Max': 1000, 'Step': 1, 'Label': 'Component Width (mm)'},
            'Height':         {'Type': 'real', 'Value':      400,  'Min': 100, 'Max': 1000, 'Step': 1, 'Label': 'Component Height (mm)'},
            'Depth':          {'Type': 'real', 'Value':       15,  'Min':  10, 'Max':  100, 'Step': 1, 'Label': 'Component Depth (mm)'},
            'Radius':         {'Type': 'dual', 'Value': [ 5,  15], 'Min':   1, 'Max':  50,  'Step': 1, 'Label': 'Element Radius (mm)'},
            'Extrusion':      {'Type': 'dual', 'Value': [-10, 10], 'Min': -25, 'Max':  25,  'Step': 1, 'Label': 'Element Height (mm)'},
            'Segments':       {'Type': 'dual', 'Value': [31,  32], 'Min':   3, 'Max':  32,  'Step': 1, 'Label': 'Element Segments (#)'},
            'Rotation':       {'Type': 'real', 'Value':        0,  'Min':   0, 'Max':  359, 'Step': 1, 'Label': 'Element Rotation (°)'},
            'Spacing':        {'Type': 'real', 'Value':        5,  'Min':   0, 'Max':   20, 'Step': 1, 'Label': 'Element Spacing (mm)'},
            'Margin':         {'Type': 'real', 'Value':        5,  'Min':   0, 'Max':   20, 'Step': 1, 'Label': 'Element Margin (mm)'} },
            'Randomness':     {               'Type': 'fold',
            'Seed':           {'Type': 'real', 'Value':  17, 'Min':   0, 'Max': 1000, 'Step': 1, 'Label': 'Random Seed'},
            'Gaussian':       {'Type': 'bool', 'Value': False, 'Label': 'Gaussian'},
            'Mean':           {'Type': 'real', 'Value': 1.0, 'Min':   0, 'Max':   1, 'Step': 0.01, 'Label': 'Gaussian Mean'},
            'Sigma':          {'Type': 'real', 'Value': 1.0, 'Min':   0, 'Max':   1, 'Step': 0.01, 'Label': 'Gaussian Sigma'}},
            'Constraints':    {               'Type': 'fold',
            'Bounded':        {'Type': 'bool', 'Value': False, 'Label': 'Within Boundary'},
            'Overlapped':     {'Type': 'bool', 'Value': False, 'Label': 'Allow Overlaps'},
            'Ordered':        {'Type': 'bool', 'Value': False, 'Label': 'Grid Layout'},
            'Categorical':    {'Type': 'bool', 'Value': False, 'Label': 'Uniform Elements'},
            'Collisions':     {'Type': 'bool', 'Value': False, 'Label': 'Show Collisions'} },
            'Statistics':     {                'Type': 'fold', 'Hint': '',
            'Collisions':     {'Type': 'dump', 'Value':   'N/A', 'Label': 'Shape Collisions (#)' },
            'Density':        {'Type': 'dump', 'Value':   'N/A', 'Label': 'Shape Density (objs/100cm²)' },
            'TypeEntropy':    {'Type': 'dump', 'Value':   'N/A', 'Label': 'Shape Type Entropy (nats)' },
            'AreaEntropy':    {'Type': 'dump', 'Value':   'N/A', 'Label': 'Shape Area Entropy (nats)' },
            'CasuEntropy':    {'Type': 'dump', 'Value':   'N/A', 'Label': 'Casu Entropy (nats²)' },
            'JointEntropy':   {'Type': 'dump', 'Value':   'N/A', 'Label': 'Joint Type-Area Entropy (nats)' },
            'BattyEntropy':   {'Type': 'dump', 'Value':   'N/A', 'Label': 'Batty Spatial Entropy (nats)' },
            'LeibEntropy':    {'Type': 'dump', 'Value':   'N/A', 'Label': 'Leibovici Entropy (nats)' },
            'DiffEntropy':    {'Type': 'dump', 'Value':   'N/A', 'Label': 'Differential Entropy (nats)' },
            'SinkEntropy':    {'Type': 'dump', 'Value':   'N/A', 'Label': 'Sinkhorn Entropy (nats)' },
            'Coverage':       {'Type': 'dump', 'Value':   'N/A', 'Label': 'Shape Coverage (%)' },
            'Rasterized':     {'Type': 'plot', 'Value':   'iVBORw0KGgoAAAANSUhEUgAAACAAAAABCAYAAAC/iqxnAAAADElEQVR4nGNgGGAAAACBAAFuXGsbAAAAAElFTkSuQmCC'},
            '3D Model':       {                 'Type': 'fold', 'Hint': '',
            'ExportStl':      {'Type': 'down', 'Value':   'Stl', 'Label': 'Download STL (union)' },
            'ExportObj':      {'Type': 'down', 'Value':   'Obj', 'Label': 'Download OBJ (multipart)' },
            'Export3mf':      {'Type': 'down', 'Value':   '3md', 'Label': 'Download 3MF (multipart)' } },
            'Table':          {'Type': 'data', 'Value':   [[]], 'Label': 'Data Table' },
            'ExportJson':     {'Type': 'down', 'Value':  'Json', 'Label': 'Download Json (design)' }
            }
        } )

    def Name( self ):
        return "Classic"

    def BaseHollow( self ) -> Mesh:
        dx, dy, dz = self.Dimensions
        bt = Mesh.Box( Vec3( 0, 0,   0 ), Vec3( dx, dy, 0.001 ) )
        bb = Mesh.Box( Vec3( 0, 0, -dz ), Vec3( dx, dy, 0.001 ) )
        return Mesh.Join( [bt, bb] ).Paint( Rgba.Types10[-1] ).Categorize( 'base' )

    def BaseSolid( self ) -> Mesh:
        dx, dy, dz = self.Dimensions
        return Mesh.Box( Vec3(  0,  0, -dz / 2 ),
                         Vec3( dx, dy,  dz ) ).Paint( Rgba.Types10[-1] ).Categorize( 'base' )

    @property
    def Dimensions( self ) -> tuple[float, float, float]:
        return ( self.Attributes.Dimensions.Width.Value,
                 self.Attributes.Dimensions.Height.Value,
                 self.Attributes.Dimensions.Depth.Value )

    @property
    def Radius( self ) -> float:
        return self.Attributes.Dimensions.Radius.Value

    @property
    def Height( self ) -> float:
        return self.Attributes.Dimensions.Extrusion.Value

    @property
    def Segments( self ) -> int:
        return self.Attributes.Dimensions.Segments.Value

    @property
    def Rotation( self ) -> float:
        return self.Attributes.Dimensions.Rotation.Value * Vec1.D2R

    @property
    def Population( self ) -> int:
        return self.Attributes.Diversity.Population.Value

    def RelativeAbundance( self, index: int ) -> float:
        return self.Attributes.Diversity.Abundances['Item' + str(index)]

    @property
    def Abundances( self ) -> np.ndarray:
        abundances = np.array( [self.RelativeAbundance( index )
            for index in range( self.Types )], dtype=float)
        expected = abundances * self.Population / np.sum( abundances )
        counts = np.round( expected ).astype( int )
        diff = self.Population - np.sum( counts )
        if diff != 0:
            order = np.argsort( -expected )
            for index in range( abs( diff ) ):
                idx = order[index % len( order )]
                counts[idx] += np.sign( diff )
        classes = np.repeat( np.arange( len( counts ) ), counts )
        np.random.shuffle( classes )
        #print( self.Types, abundances, classes )
        return classes

    @property
    def IsGaussian( self ) -> bool:
        return self.Attributes.Randomness.Gaussian.Value

    @property
    def Mean( self ) -> float:
        return self.Attributes.Randomness.Mean.Value

    @property
    def Sigma( self ) -> float:
        return self.Attributes.Randomness.Sigma.Value

    @property
    def IsBounded( self ) -> bool:
        return self.Attributes.Constraints.Bounded.Value

    @property
    def IsCategorical( self ) -> bool:
        return self.Attributes.Constraints.Categorical.Value

    @property
    def IsOverlapped( self ) -> bool:
        return self.Attributes.Constraints.Overlapped.Value

    @property
    def IsOrdered( self ) -> bool:
        return self.Attributes.Constraints.Ordered.Value

    @property
    def ShowCollisions( self ) -> bool:
        return self.Attributes.Constraints.Collisions.Value

    @property
    def Types( self ) -> int:
        return self.Attributes.Diversity.Types.Value

    @property
    def Seed( self ) -> int:
        return self.Attributes.Randomness.Seed.Value

    @property
    def Margin( self ) -> float:
        return self.Attributes.Dimensions.Margin.Value

    @property
    def Spacing( self ) -> float:
        return self.Attributes.Dimensions.Spacing.Value

    def InitializeSolution( self ):
        self.Solution = np.zeros( ( self.Population, N ) )
        return self

    def ComputeSizes( self, abundances ):
        ro, ri = self.Radius
        ho, hi = self.Height
        so, si = self.Segments
        ao, ai = 0, self.Rotation

        radius = np.random.uniform( ro, ri, self.Population )
        height = np.random.uniform( ho, hi, self.Population )
        angles = np.random.uniform( ao, ai, self.Population )
        planes = np.random.uniform( so, si, self.Population ).astype( int )

        if( self.IsCategorical ):
            cat_radius = { }
            cat_height = { }
            cat_planes = { }
            cat_angles = { }
            for index, type in enumerate( abundances ):
                cat_radius[type] = radius[index]
                cat_height[type] = height[index]
                cat_planes[type] = planes[index]
                cat_angles[type] = angles[index]
            radius = cat_radius
            height = cat_height
            planes = cat_planes
            angles = np.radians( angles )
        return radius, height, planes, angles

    def LayoutUnconstrained( self ):
        self.InitializeSolution( )
        abundances = self.Abundances
        radius, height, planes, angles = self.ComputeSizes( abundances )

        dx, dy, _ = self.Dimensions
        m, s = self.Mean, self.Sigma
        delta = max( dx, dy ) * 0.5
        clusters = [
            ( np.random.uniform( -m * dx / 2, m * dx / 2 ),
              np.random.uniform( -m * dy / 2, m * dy / 2 ),
              np.random.uniform( 0.0, delta * s ) )
              for _ in abundances ]

        for index, type in enumerate( abundances ):
            source = type if self.IsCategorical else index
            if( self.IsGaussian ):
                cx, cy, sigma = clusters[type]
                x = np.random.normal( cx, sigma )
                y = np.random.normal( cy, sigma )
            else:
                x = np.random.uniform( -dx / 2, dx / 2 )
                y = np.random.uniform( -dy / 2, dy / 2 )
            self.Solution[index, X] = x
            self.Solution[index, Y] = y
            self.Solution[index, R] = radius[source]
            self.Solution[index, H] = height[source]
            self.Solution[index, T] = type
            self.Solution[index, S] = planes[source]
            self.Solution[index, A] = angles[source]
        return self

    def LayoutBounded( self ):
        self.LayoutUnconstrained( )
        dx, dy, _ = self.Dimensions
        for index in range( len( self.Solution ) ):
            x = self.Solution[index, X]
            y = self.Solution[index, Y]
            r = self.Solution[index, R]
            s = r + self.Margin
            self.Solution[index, X] = np.clip( x, -dx/2 + s, dx/2 - s )
            self.Solution[index, Y] = np.clip( y, -dy/2 + s, dy/2 - s )
        return self

    def LayoutOrdered( self ):
        self.LayoutUnconstrained( )
        count = len( self.Solution )

        dx, dy, _ = self.Dimensions
        nx, ny = (int(np.ceil(np.sqrt(count * dx / dy))),
                  int(np.ceil(np.sqrt(count * dy / dx))))
        grid = np.zeros((nx, ny, 2))
        for ix in range(nx):
            for iy in range(ny):
                grid[ix, iy, X] = (ix + 0.5) * dx / nx - dx / 2
                grid[ix, iy, Y] = (iy + 0.5) * dy / ny - dy / 2

        used = -np.ones((nx, ny), dtype=int)
        cells = np.arange(nx*ny)
        np.random.shuffle(cells)
        for index in range(count):
            cell = cells[index]
            ix, iy = cell % nx, cell // nx
            used[ix, iy] = index
            self.Solution[index, X] = grid[ix, iy, X]
            self.Solution[index, Y] = grid[ix, iy, Y]

        if (self.IsBounded):
            hx, hy, m = dx/2, dy/2, self.Margin
            for index in range(count):
                x = self.Solution[index, X]
                y = self.Solution[index, Y]
                r = self.Solution[index, R]
                if (x - r < -hx + m):
                    self.Solution[index, R] = x + hx - m
                if (x + r > hx - m):
                    self.Solution[index, R] = hx - x - m
                if (y - r < -hy + m):
                    self.Solution[index, R] = y + hy - m
                if (y + r > hy - m):
                    self.Solution[index, R] = hy - y - m

        if (not self.IsOverlapped):
            ro, ri = self.Radius
            def Clearance(ox, oy, ix, iy):
                if (ix >= nx or iy >= ny):
                    return
                source = used[ox, oy]
                target = used[ix, iy]

                if (source < 0 or target < 0):
                    return
                s = self.Solution[source]
                t = self.Solution[target]

                distance = np.sqrt((s[X] - t[X])**2 + (s[Y] - t[Y])**2)
                overlap = s[R] + t[R] - distance + self.Spacing
                if (overlap > 0):
                    overlap *= 0.5
                    self.Solution[source, R] = np.clip( s[R] - overlap, ro, ri )
                    self.Solution[target, R] = np.clip( t[R] - overlap, ro, ri )

            for ix in range(nx):
                for iy in range(ny):
                    Clearance(ix, iy, ix + 1, iy + 0)
                    Clearance(ix, iy, ix + 0, iy + 1)
                    Clearance(ix, iy, ix + 1, iy + 1)

        if (self.IsCategorical):
            self.ResolveCategories()
        return self

    @property
    def HasInvalidDimensions( self ) -> bool:
        valid = 0
        ro, ri = self.Radius
        for index in range(len(self.Solution)):
            valid += ro <= self.Solution[index, R] <= ri
        return valid

    def ShapeCollisions( self, epsilon=1e-3 ):
        collisions = []
        count = len( self.Solution )
        for source in range( count - 1 ):
            for target in range( source + 1, count ):
                s = self.Solution[source]
                t = self.Solution[target]
                distance = np.sqrt( ( s[X] - t[X] ) ** 2 +
                                    ( s[Y] - t[Y] ) ** 2 )
                overlap = s[R] + t[R] - distance + self.Spacing
                if( overlap > epsilon ): collisions.append(
                    ( source, target, overlap ) )
        return collisions

    def ResolveCategories( self ):
        sizes = {t: list() for t in range(self.Types)}
        for index in range(len(self.Solution)):
            t = int(self.Solution[index, T])
            r = self.Solution[index, R]
            sizes[t].append(r)
        for t in sizes:
            sizes[t] = np.mean(sizes[t])
        for index in range(len(self.Solution)):
            t = int(self.Solution[index, T])
            self.Solution[index, 2] = sizes[t]
        return self

    def ResolveCollisions(self, iterations=100, strength=0.75):
        shapes = self.Solution
        dx, dy, _ = self.Dimensions
        hx, hy = dx / 2, dy / 2
        count = len(self.Solution)
        for _ in range(iterations):
            for source in range(count):
                for target in range(source + 1, count):
                    dx = shapes[target, X] - shapes[source, X]
                    dy = shapes[target, Y] - shapes[source, Y]
                    distance = np.hypot(dx, dy)
                    clearance = shapes[source, R] + shapes[target, R] + self.Spacing
                    if(distance < clearance):
                        overlap = clearance - distance
                        fx = 0.5 * strength * overlap * dx / distance
                        fy = 0.5 * strength * overlap * dy / distance

                        shapes[source, X] -= fx
                        shapes[source, Y] -= fy
                        shapes[target, X] += fx
                        shapes[target, Y] += fy
            for source in range(count):
                s = shapes[source, R] + (self.Margin if self.IsBounded else 0)
                shapes[source, X] = np.clip(shapes[source, X], -hx + s, hx - s)
                shapes[source, Y] = np.clip(shapes[source, Y], -hy + s, hy - s)
        return self

    def ConstructMeshes( self, epsilon: float=0.1 ) -> Model:
        for shape in self.Solution:
            mesh = Mesh.Cylinder(
                radius   =      shape[R],
                height   = abs( shape[H] ),
                sections = int( shape[S] ) )
            mesh.Rotate( Vec3.ZAxis, shape[A]  + np.pi / (
                4 if ( shape[S] == 4 ) else 2 ) )
            mesh.Translate( Vec3( shape[X], shape[Y],
                -shape[H] / 2 + ( epsilon if shape[H] >= 0 else -epsilon ) ) )
            mesh.Paint( Rgba.Types10[int( shape[T] )] )
            mesh.Categorize( 'positive' if shape[H] < 0 else 'negative' )
            self.Meshes.Add( mesh )
        return self

    def AreaCoverage( self, width: int=256 ) -> tuple[float, str]:
        dx, dy, _ = self.Dimensions
        height = int( width * dy / dx )

        image = Image.new( "P", ( width, height ), 0xff )
        #print( len( Rgba.TypesFF ), Rgba.TypesFF )
        image.putpalette( Rgba.TypesFF )

        canvas = ImageDraw.Draw( image )
        for shape in self.Solution:
            xo = int( ( shape[X] + dx / 2 ) * width / dx )
            yo = int( height - ( shape[Y] + dy / 2 ) * height / dy )
            ro = int( shape[R] * width / dx )
            sides = int( shape[S] )
            angle = shape[A] + np.pi / ( 4 if ( shape[S] == 4 ) else 2 )

            vertices = []
            for k in range( sides ):
                theta = 2 * np.pi * k / sides - angle
                x = xo + ro * np.cos( theta )
                y = yo + ro * np.sin( theta )
                vertices.append( ( x, y ) )
            canvas.polygon( vertices, fill=int( shape[T] ), outline=None )

        data = np.array( image )
        coverage = float( np.sum( data != 255 ) / ( width * height ) )
        return ( coverage, encode( image ) )

    @property
    def Entropies(self):
        points   = self.Solution[:,:2]
        types    = self.Solution[:, T].astype( int )
        segments = self.Solution[:, S]
        radius   = self.Solution[:, R]
        height   = self.Solution[:, H]

        angle = np.pi / segments
        area = segments * radius * (
            ( radius * np.sin( 2 * angle ) ) +
            ( 2 * np.abs( height ) * np.sin( angle ) ) )

        dx, dy = self.Dimensions[:2]
        dx, dy = dx / 2, dy / 2
        count = int( np.ceil( np.sqrt( len( points ) ) ) )
        # grid = np.array( np.meshgrid(
        #     np.linspace( -dx, dx, count ),
        #     np.linspace( -dy, dy, count ) ) ).reshape( 2, -1 ).T

        ex, ey = self.Dimensions[:2]
        if( self.IsBounded ):
            ex, ey = ex - 2 * self.Margin, ey - 2 * self.Margin
        gx = int( np.ceil( np.sqrt( len( points ) * ex / ey ) ) )
        gy = int( np.ceil( np.sqrt( len( points ) * ey / ex ) ) )
        grid = np.array( [
            ( (ix + 0.5) * ex / gx - ex / 2, (iy + 0.5) * ey / gy - ey / 2 )
            for ix in range( gx ) for iy in range( gy ) ] )

        unique, counts = np.unique( types, return_counts=True )
        categories = len( unique )
        bins = max( 2, categories )
        type_entropy = shannon( counts, base=np.e )
        area_entropy = shannon( np.array( [area[type==types].sum( ) for type in unique] ), base=np.e )
        joint_entropy = joint( types, area, bins=bins, base=np.e )
        batty_entropy = batty( points, bins=count, extent=[[-dx, dx], [-dy, dy]], base=np.e )
        diff_entropy = eigenvalues( points, base=np.e )[-1]
        sink_entropy, sink_max = sinkhorn( points, grid, base=np.e )[2:4]

        leib_radius = np.arange( 1, 10 ) * ( max( self.Dimensions ) / 20 )
        leib_entropy = leibovici( points, types,
            base=np.e, radius=leib_radius, normalize=False )[1]

        category_max = np.log( categories )
        cells = count ** 2

        return {
            'Type':  ( type_entropy,  0.0, category_max ),
            'Area':  ( area_entropy,  0.0, category_max ),
            'Casu':  ( type_entropy * area_entropy, 0.0, category_max ** 2 ),
            'Joint': ( joint_entropy, 0.0, np.log( categories * bins ) ),
            'Batty': ( batty_entropy, -np.log( cells ), 0.0 ),
            'Leib':  ( leib_entropy,  0.0, 2 * category_max ),
            'Diff':  ( diff_entropy,  0.0, np.log( 2 ) ),
            'Sink':  ( sink_entropy,  None, None ) }

    @property
    def Density(self):
        dx, dy, _ = self.Dimensions
        return 1e4 * len(self.Solution) / (dx * dy)

    def AddCollision( self, collision ) -> Model:
        source, target, _ = collision
        sx = self.Solution[source,X]
        sy = self.Solution[source,Y]
        tx = self.Solution[target,X]
        ty = self.Solution[target,Y]
        self.Meshes.Add( Mesh.Line(
            Vec3( sx, sy, 0 ),
            Vec3( tx, ty, 0 ),
            radius   = self.CurveRadius,
            sections = self.CurveAround ).Paint(
                [0x00, 0x00, 0xff, 0xff] ) )
        return self

    def Upload( self, name, data ):
        if( name.endswith( '.json' ) ):
            return self.Update( deserialize( data.to_py( ).tobytes( ) ) )
        else:
            data = bytes( data.to_py( ) )
            data = pickle.loads( data, encoding='latin1' )

            self.Solution = np.zeros( ( len( data ), N ) )
            for index, row in enumerate( data ):
                self.Solution[index, X] = row[4][0] - 200
                self.Solution[index, Y] = 200 - row[4][1]
                self.Solution[index, R] = row[4][2] / 2
                self.Solution[index, H] = row[4][3]
                self.Solution[index, T] = ord( row[0] ) - ord( 'A' )
                self.Solution[index, S] = 32
                self.Solution[index, A] = 0

            self.Meshes.Clear( )
            self.Meshes.Add( self.BaseHollow( ) )
            self.ConstructMeshes( )
            return self.Flush( self.Measure( ) )

    def Tabulate( self ) -> list[list[str]]:
        table = [['S/N','Uid', 'X', 'Y', 'Rad', 'Hgt', 'Seg', 'Ang', 'RGB']]
        for index, shape in enumerate( self.Solution ):
            color = Rgba.Types10[int( shape[T] )]
            table.append( [
                f'{index+1}',
                f'{chr( 65 + int(shape[T]) )}',
                f'{shape[X]:.1f}',
                f'{shape[Y]:.1f}',
                f'{shape[R]:.1f}',
                f'{shape[H]:.1f}',
                f'{shape[S]:.0f}',
                f'{shape[A]:.1f}',
                f'#{color[0]:02X}{color[1]:02X}{color[2]:02X}'] )
        return table

    def Measure( self ) -> dict:
        collisions = self.ShapeCollisions( )
        coverage, image = self.AreaCoverage( )
        entropies = self.Entropies

        def format( key ):
            value, minimum, maximum = entropies[key]
            text = f'{value:.5f}'
            if( maximum is not None ):
                text += f' ({relative( value, minimum, maximum ) * 100:.2f}%)'
            return text

        statistics = {
            'Coverage': f'{coverage*100:.2f}%',
            'Rasterized': image,
            'TypeEntropy':  format( 'Type' ),
            'AreaEntropy':  format( 'Area' ),
            'CasuEntropy':  format( 'Casu' ),
            'JointEntropy': format( 'Joint' ),
            'BattyEntropy': format( 'Batty' ),
            'LeibEntropy':  format( 'Leib' ),
            'DiffEntropy':  format( 'Diff' ),
            'SinkEntropy':  format( 'Sink' ),
            'Density': f'{self.Density:.3f}',
            'Collisions': f'{len(collisions)}',
            'Table': self.Tabulate( ) }

        if( self.ShowCollisions ):
            for collision in collisions:
                self.AddCollision( collision )
        return statistics

    def Update( self, attributes ):
        self.Reset( attributes )
        np.random.seed( self.Seed )

        self.Meshes.Add( self.BaseSolid( ) )

        if( self.IsOrdered ):
            self.LayoutOrdered( )
        else:
            if( self.IsBounded ):
                self.LayoutBounded( )
            else:
                self.LayoutUnconstrained( )
            if( not self.IsOverlapped ):
                self.ResolveCollisions( )

        self.ConstructMeshes( )
        return self.Flush( self.Measure( ) )