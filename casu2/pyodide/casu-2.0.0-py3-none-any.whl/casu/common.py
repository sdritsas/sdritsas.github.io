from email.mime import base
import json, io, base64, numpy as np, datetime

class dynamic:
    def __init__( self, dictionary ):
        for key, value in dictionary.items( ):
            if isinstance( value, dict ):
                setattr( self, key, dynamic( value ) )
            else:
                setattr( self, key, value )

    def __getitem__( self, key ):
        return getattr( self, key )

    def ToDict( self ):
        result = {}
        for key, value in self.__dict__.items():
            if isinstance(value, dynamic):
                result[key] = value.ToDict()
            elif isinstance(value, list):
                result[key] = [
                    v.ToDict() if isinstance(v, dynamic) else v for v in value
                ]
            else:
                result[key] = value
        return result
    def __repr__( self ):
        return str( self.ToDict( ) )

def timestamp( suffix ):
    now = datetime.datetime.now( )
    return now.strftime( '%y.%m.%d %H.%M.%S' ) + suffix

def serialize( instance : object ) -> str:
    return json.dumps( instance,
        default=lambda o: o.__dict__, indent=4 )

def deserialize( text : str ) -> object:
    return dynamic( json.loads( text ) )

def encode( image ) -> str:
    bytes = io.BytesIO( )
    image.save( bytes, format='PNG' )
    return base64.b64encode( bytes.getvalue( ) ).decode( 'utf-8' )

def shannon( counts, base = 2 ) -> float:
    p = counts / np.sum( counts ); p = p[p > 0]
    return float( -np.sum( p * np.log( p ) / np.log( base ) ) )

def joint( types, values, bins = None, base = 2 ) -> float:
    codes, labels = np.unique( types, return_inverse=True )
    bins = max( 2, len( codes ) ) if bins is None else bins
    edges = np.linspace( np.min( values ), np.max( values ), bins + 1 )
    binned = np.clip( np.digitize( values, edges[1:-1] ), 0, bins - 1 )
    pairwise = labels * bins + binned
    counts = np.bincount( pairwise, minlength=len( codes ) * bins )
    return shannon( counts, base=base )

def batty( points, bins = 10, extent = None, base = 2 ) -> float:
    if( extent is None ):
        extent = [ [ np.min( points[:,0] ), np.max( points[:,0] ) ],
                   [ np.min( points[:,1] ), np.max( points[:,1] ) ] ]

    counts, _, _ = np.histogram2d(
        points[:,0], points[:,1], bins=bins, range=extent )
    counts = counts.ravel( )

    p = counts / np.sum( counts )
    a = np.full_like( p, 1.0 / counts.size )
    p, a = p[p > 0], a[p > 0]

    return float( -np.sum( p * np.log( p / a ) / np.log( base ) ) )

def eigenvalues( points, base = 2 ):
    a, b = np.linalg.eigvalsh( np.cov( points, rowvar=False ) )
    s = 1.0 / ( a + b )
    A, B = a * s, b * s
    e = ( A * np.log( A + 1e-7 ) +
          B * np.log( B + 1e-7 ) ) / -np.log( base )
    return float( a ), float( b ), float( e )

def sinkhorn( sources, targets, reg=None, n=1000, e=1e-7, base=2 ):
    M = np.sqrt( np.sum( sources**2, axis=1 )[:,None] +
                 np.sum( targets**2, axis=1 )[None,:] -
                 2 * sources @ targets.T )
    r = 0.05 * np.median( M ) if reg is None else reg
    K = np.exp( -M / r )

    A = len( sources ); a = 1.0 / A
    B = len( targets ); b = 1.0 / B

    u = np.ones( A )
    v = np.ones( B )
    w = np.ones( A )

    for i in range( n ):
        w[:] = u[:]
        u = a / ( K   @ v )
        v = b / ( K.T @ u )
        #d = np.linalg.norm(u - w, 1)
        d = np.max( np.abs( u - w ) )
        if d <= e: break

    T = np.outer( u, v ) * K
    cost = np.sum( T * M )
    mask = T > 0
    entropy = -np.sum(T[mask] * np.log(T[mask])) / np.log(base)
    max_entropy = 0.5 * np.log( T.size ) / np.log(base)

    return T, float( cost ), float( entropy ), float( max_entropy )

def leibovici( points, types, radius = None, base = 2, normalize = False ):
    categories = len( np.unique( types ) )
    distances = np.linalg.norm(
        points[:, None, :] -
        points[None, :, :], axis=2 )

    if( radius is None ):
        maximum = np.max( distances )
        radiuses = [maximum * 0.25]
    elif isinstance( radius, ( int, float ) ):
        if ( radius <= 0 ):
            maximum = np.max( distances )
            radius = -radius
            radiuses = np.arange( 1, radius ) * ( maximum / radius )
        else:
            radiuses = [radius]
    else:
        radiuses = radius
    radiuses = np.array( radiuses )

    entropies = []
    for radius in radiuses:
        source, target = np.where(
            ( distances > 0 ) &
            ( distances <= radius ) )

        pairwise = types[source] * categories + types[target]
        counts = np.bincount( pairwise, minlength=categories ** 2 )

        probs = counts / counts.sum( ); probs = probs[probs > 0]
        entropy = -np.sum( probs * np.log( probs ) / np.log( base ) )
        if( normalize ): entropy /= np.log( categories ** 2 ) / np.log( base )
        entropies.append( entropy )
    entropies = np.array( entropies )
    return ( entropies, float( np.mean( entropies ) ), radiuses )